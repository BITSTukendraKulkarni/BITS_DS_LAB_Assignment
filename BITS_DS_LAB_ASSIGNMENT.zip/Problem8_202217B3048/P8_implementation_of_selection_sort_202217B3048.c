#include <stdio.h>

void selection_sort(int array[], int size) {
    int i, j, min_idx, temp;

    for (i = 0; i < size - 1; i++) {
        min_idx = i;
        for (j = i + 1; j < size; j++) {
            if (array[j] < array[min_idx]) {
                min_idx = j;
            }
        }
        temp = array[min_idx];
        array[min_idx] = array[i];
        array[i] = temp;
    }
}

int main() {
    int array[] = {64, 25, 12, 22, 11, 90};
    int size = sizeof(array) / sizeof(array[0]);

    selection_sort(array, size);

    printf("Sorted array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}
